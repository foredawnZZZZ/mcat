<template>
  <header class="header">
    <h1>黑马程序员-上海校区（前端学院）</h1>
  </header>
</template>

<script>
export default {

}
</script>

<style lang="stylus" scoped>
  .header
    background-color: #ffd600;
    height: 4.5rem;
    h1
      height: 4.5rem;
      line-height: 4.5rem;
      font-size: 1.4rem;
      font-weight: 700;
      text-align: center;

</style>
