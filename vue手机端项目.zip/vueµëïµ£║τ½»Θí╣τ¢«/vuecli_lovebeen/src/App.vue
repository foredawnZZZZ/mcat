<template>
  <div id="app">
    <!-- 标题 -->
    <router-view/>
    <!-- 页脚 -->
  </div>
</template>

<script>
export default {
  name: 'App'
}
</script>

<style>

</style>
